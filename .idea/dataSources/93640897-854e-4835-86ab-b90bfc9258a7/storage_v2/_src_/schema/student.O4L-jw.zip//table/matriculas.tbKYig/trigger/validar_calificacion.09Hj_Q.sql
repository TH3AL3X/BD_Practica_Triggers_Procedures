create definer = root@localhost trigger Validar_Calificacion
    after update
    on matriculas
    for each row
BEGIN
        UPDATE Matriculas SET calificacion =
            CASE
                WHEN NEW.calificacion < 0 THEN 0
                WHEN NEW.calificacion > 10 THEN 10
                ELSE NEW.calificacion
            END
        WHERE id = NEW.id;
    END;


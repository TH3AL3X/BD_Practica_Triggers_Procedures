create definer = root@localhost trigger Validar_Calificacion_Insert
    after insert
    on matriculas
    for each row
BEGIN
        UPDATE Matriculas SET calificacion =
            CASE
                WHEN NEW.calificacion < 0 THEN 0
                WHEN NEW.calificacion > 10 THEN 10
                ELSE NEW.calificacion
            END
        WHERE id = NEW.id;
    END;


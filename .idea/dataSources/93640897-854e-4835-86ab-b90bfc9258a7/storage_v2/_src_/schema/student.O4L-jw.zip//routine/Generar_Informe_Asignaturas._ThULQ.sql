create
    definer = root@localhost procedure Generar_Informe_Asignaturas()
BEGIN
        DECLARE done INT DEFAULT FALSE;
        DECLARE asignatura_id INT;
        DECLARE asignatura_nombre VARCHAR(255);
        DECLARE calificacion_media DECIMAL(5, 2);
        DECLARE cur CURSOR FOR
            SELECT Asignaturas.asignatura_id, Asignaturas.nombre, AVG(Matriculas.calificacion)
            FROM Asignaturas
            LEFT JOIN Matriculas ON Asignaturas.asignatura_id = Asignaturas.asignatura_id
            GROUP BY Asignaturas.asignatura_id;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

        TRUNCATE TABLE Informes_Asignaturas;

        OPEN cur;
        read_loop: LOOP
            FETCH cur INTO asignatura_id, asignatura_nombre, calificacion_media;
            IF done THEN
                LEAVE read_loop;
            END IF;
            INSERT INTO Informes_Asignaturas (id, nombre, calificacion_media)
            VALUES (asignatura_id, asignatura_nombre, calificacion_media);
        END LOOP;
        CLOSE cur;
    END;


create definer = root@localhost trigger Insertar_Informes_Updates
    before update
    on matriculas
    for each row
BEGIN
        call Insertar_Informes();
END;


create
    definer = root@localhost procedure Insertar_Informes()
BEGIN
        DECLARE completado INT DEFAULT FALSE;
        DECLARE nombre VARCHAR(50);
        DECLARE calificacion_media FLOAT;

        DECLARE datos_asignaturas CURSOR FOR
            SELECT Asignaturas.nombre, AVG(Matriculas.calificacion) FROM Asignaturas
               INNER JOIN Matriculas ON Asignaturas.asignatura_id = Asignaturas.asignatura_id GROUP BY Asignaturas.asignatura_id;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET completado = TRUE;

        DELETE FROM informes_asignaturas WHERE id<0;

        OPEN datos_asignaturas;
        read_loop: LOOP
            FETCH datos_asignaturas INTO nombre, calificacion_media;
            IF completado THEN
              LEAVE read_loop;
            END IF;
            INSERT INTO informes_asignaturas (nombre, calificacion_media) VALUES (nombre, calificacion_media);
        end loop;

        CLOSE datos_asignaturas;

    END;

